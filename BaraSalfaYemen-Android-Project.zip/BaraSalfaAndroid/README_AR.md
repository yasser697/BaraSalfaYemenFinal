# برا السالفة اليمنية — مشروع Android

هذا مشروع Android يستخدم WebView محليًا لفتح ملف اللعبة الأصلي `app/src/main/assets/index.html` مع تفعيل JavaScript وDOM Storage.

## بناء APK عبر GitHub
1. ارفع محتويات هذا المجلد إلى جذر مستودع GitHub (وليس ملف ZIP وحده).
2. افتح تبويب Actions وشغّل `Build Bara Salfa Yemen APK` أو انتظر البناء التلقائي بعد الرفع.
3. من عملية البناء الناجحة، نزّل Artifact باسم `Bara-Salfa-Yemen-APK`؛ يحتوي على `app-debug.apk`.

ملاحظة: لم يتم اختبار التطبيق على جهاز Android فعلي هنا؛ يجب تجربة ملف APK الناتج للتأكد من تشغيل اللعبة.
