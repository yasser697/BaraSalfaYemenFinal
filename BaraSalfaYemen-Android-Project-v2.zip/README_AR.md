# برا السالفة اليمنية — مشروع Android

هذا المشروع يحزم ملف HTML الأصلي داخل تطبيق Android باستخدام WebView.

## بناء APK عبر GitHub Actions
1. ارفع **محتويات هذا المجلد** إلى جذر مستودع GitHub (وليس المجلد نفسه أو ملف ZIP فقط).
2. تأكد أن `.github/workflows/build-apk.yml` موجود في جذر المستودع.
3. افتح Actions وشغّل `Build Bara Salfa Yemen APK`.
4. عند نجاح العملية، افتح نتيجة التشغيل ونزّل Artifact باسم `Bara-Salfa-Yemen-APK` ثم فك ZIP لتحصل على `app-debug.apk`.

ملاحظة: هذا مشروع Debug للتجربة والتثبيت، وليس إصدارًا موقّعًا للنشر في Google Play.
